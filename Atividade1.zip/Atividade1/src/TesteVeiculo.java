public class TesteVeiculo {

	public static void main(String[] args) {
		
				Veiculo v1;

				v1 = new Veiculo();
				v1.velocidade = 60;
				v1.status = false;

				v1.ligar();
				v1.acelerar();

				System.out.println(v1.mostrarStatus());

				v1.desligar();

				System.out.println(v1.mostrarStatus());

	}

}