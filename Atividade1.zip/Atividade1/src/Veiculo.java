public class Veiculo {
	
	public int velocidade;
	public boolean status;

	public void ligar() {
		status = true;
	}

	public void desligar() {
		status = false;
	}

	public void acelerar() {
		velocidade ++;
	}

	public String mostrarStatus() {
		String mostrar = "";
		if(status==true) {
			mostrar = "Ligado";
		}else {
			mostrar = "Desligado";
		}
		return mostrar;
	}

}